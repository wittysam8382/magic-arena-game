export class Player {
  constructor(id, name, health, strength, attack) {
    this.id = id;
    this.name = name;
    this.health = health;
    this.strength = strength;
    this.attack = attack;
  }
}
